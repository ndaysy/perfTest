# Windows Server Crawler Safe Tuning

日期：2026-07-30  
适用场景：Windows Server 2025/2022/2016 云主机作为爬虫 worker，远程连接操作，不允许造成网络或 RDP 异常。

## 目标

降低爬虫专用主机的默认后台服务、UI、诊断、维护任务占用，减少 2GB 内存规格下 browser 模式的系统底噪。该方案不修改爬虫业务逻辑，不修改 pagefile，不修改网络配置。

## 安全边界

脚本明确不处理以下服务或配置：

- RDP：`TermService`、`UmRdpService`、`SessionEnv`
- 网络核心：`Dhcp`、`Dnscache`、`NlaSvc`、`BFE`、`mpssvc`
- 远程/共享：`LanmanServer`、`LanmanWorkstation`、`WinRM`
- 云厂商 agent：`YDService`、`YDLive`、`BaradAgentSvc`、`StargateSvc`、`tatsvc`
- 系统核心：`RpcSs`、`DcomLaunch`、`RpcEptMapper`、`EventLog`、`Schedule`、`Winmgmt`、`PlugPlay`、`ProfSvc`、`CryptSvc`、`Power`
- 不修改：防火墙规则、路由、网卡、DNS、hosts、pagefile、注册表服务模板。

## 脚本

可复用脚本：

```powershell
C:\wind\spider\tools\apply_windows_crawler_safe_tuning.ps1
```

模式：

```powershell
# 只记录当前状态，不修改系统
powershell.exe -ExecutionPolicy Bypass -File C:\wind\spider\tools\apply_windows_crawler_safe_tuning.ps1 -Mode Snapshot

# 应用安全精简
powershell.exe -ExecutionPolicy Bypass -File C:\wind\spider\tools\apply_windows_crawler_safe_tuning.ps1 -Mode Apply

# 回滚服务启动类型，需指定 Apply 时生成的 before_services.csv
powershell.exe -ExecutionPolicy Bypass -File C:\wind\spider\tools\apply_windows_crawler_safe_tuning.ps1 -Mode Rollback -SnapshotPath C:\wind\spider\perf-runs\windows_crawler_safe_tuning_YYYYMMDD_HHMMSS\before_services.csv
```

每次运行会生成独立目录：

```text
C:\wind\spider\perf-runs\windows_crawler_safe_tuning_<timestamp>\
```

包含：

- `manifest.txt`：安全边界和候选项说明
- `actions.log`：实际动作和失败项
- `before_services.csv`
- `after_services.csv`
- `before_tasks.csv`
- `after_tasks.csv`

## Level 1 精简项

服务候选：

- `PcaSvc`：Program Compatibility Assistant
- `DPS`：Diagnostic Policy Service
- `WerSvc`：Windows Error Reporting
- `TrkWks`：Distributed Link Tracking Client
- `UALSVC`：User Access Logging
- `WpnService`、`WpnUserService_*`：推送通知
- `OneSyncSvc_*`：同步主机
- `CDPUserSvc_*`：连接设备平台用户服务
- `ShellHWDetection`：硬件自动播放检测
- `Themes`：主题服务
- `AudioSrv`、`AudioEndpointBuilder`：音频服务

计划任务候选：

- `\Microsoft\Windows\Application Experience\*`
- `\Microsoft\Windows\Customer Experience Improvement Program\*`
- `\Microsoft\Windows\Diagnosis\*`
- `\Microsoft\Windows\DiskCleanup\SilentCleanup`
- `\Microsoft\Windows\DiskFootprint\*`
- `\Microsoft\Windows\Maintenance\WinSAT`
- `\Microsoft\Windows\Server Manager\ServerManager`
- `\Microsoft\Windows\Server Manager\CleanupOldPerfLogs`
- `\Microsoft\Windows\Shell\IndexerAutomaticMaintenance`
- `\Microsoft\Windows\Bluetooth\UninstallDeviceTask`
- `\Microsoft\Windows\Printing\PrinterCleanupTask`
- `\GoogleUser\GoogleUpdater\*`

## 本机执行记录

2026-07-30 已执行：

```text
C:\wind\spider\perf-runs\windows_crawler_safe_tuning_20260730_101238\
```

成功停止/禁用的主要服务：

- `AudioSrv`
- `DPS`
- `PcaSvc`
- `ShellHWDetection`
- `Themes`
- `TrkWks`
- `UALSVC`
- `WerSvc`
- `WpnService`

尝试但部分未完全禁用：

- `AudioEndpointBuilder`：存在依赖服务，未强制停止，但启动类型已尝试设置。
- `CDPUserSvc_12b20157`、`OneSyncSvc_12b20157`、`WpnUserService_12b20157`：per-user 服务实例，`Set-Service` 返回参数错误；不使用注册表强改，避免影响登录会话。
- 一个 `GoogleUpdater` 计划任务禁用返回 Access denied，其余低风险计划任务已处理。

应用后安全复核：

- `TermService`、`UmRdpService`、`SessionEnv` 仍为 Running。
- `Dhcp`、`Dnscache`、`BFE`、`mpssvc` 仍为 Running。
- `LanmanServer`、`LanmanWorkstation`、`WinRM` 仍为 Running。
- `YDService`、`YDLive` 仍为 Running。
- `kabushiki.jp`、`info.kabushiki.jp`、`member.kabushiki.jp` 的 TCP 443 连通正常。

## 后续验证

应用该精简后，应继续跑同样压测组合：

```powershell
C:\WINDOWS\System32\WindowsPowerShell\v1.0\powershell.exe -Command "& 'C:\wind\spider\tools\run_wcb_io_probe.ps1' -Concurrency 5 -TargetDetailCount 20"
```

重点比较：

- tpm、avg、p50、p95、max
- `Available MBytes`
- `Page Reads/sec`
- `Disk Read Bytes/sec`
- `Processor Queue Length`
- Chrome data 进程读量
- `web_attachment_detector` 耗时
- `HTTPConnectionPool(host='localhost') read timeout=120` 次数

若 Level 1 对 tpm/p95 无明显收益，应保持其作为“降低底噪”的基础配置，但不要继续扩大到网络/RDP/云 agent 相关服务。下一步应优先优化 `autoAttachment` 链接探测策略和 Chrome 图形参数。

## 2026-07-30 验证结论修正

用户随后使用原始 `wcb_perf_test.exe`、原始 `C:\wcbclient\test\browser-jp.json`、并发 5、总数 50 重新压测：

```text
C:\wcbclient\perf-output\browser-5-summary_20260730T030918Z_0b8c212b.csv
throughput_per_min=5.3, avg=54.4s, p50=53.2s, p95=66.0s, max=87.7s
```

与此前关闭/调整主动防御后的可比结果相比：

```text
C:\wcbclient\perf-output\browser-5-summary_20260728T114125Z_381112fc.csv
throughput_per_min=4.8, avg=56.0s, p50=49.3s, p95=111.3s, max=171.5s
```

结论：

- Level 1 精简没有带来明确的 TPM 阶跃提升；不能把 5.3/min 归因为本次服务精简。
- 它仍可作为爬虫专用 Windows Server 的安全基线，用于降低后台任务、诊断、UI、通知类噪声。
- 当前更强的收益证据来自此前关闭/调整主动防御，以及后续对 Defender 实时检查、IOAV、排除项、签名更新任务的控制。
- 后续不要为了追求内存下降继续关闭网络、RDP、云厂商 agent 或 pagefile 相关配置。
