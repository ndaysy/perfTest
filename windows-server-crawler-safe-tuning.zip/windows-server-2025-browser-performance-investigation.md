# Windows Server 2025 浏览器模式性能定位记录

日期：2026-07-29  
测试机：Tencent Cloud CVM，Windows Server 2025 Datacenter，2 vCPU / 2GB RAM  
测试目录：`C:\wcbclient`  
项目工作区：`C:\wind\spider`

## 目标

在只能使用当前 Server 2025 测试环境的前提下，验证浏览器模式性能下降原因，并优先尝试系统侧优化。程序逻辑尽量不改；为定位问题允许新增独立测试脚本。

## 新增诊断工具

- `tools/run_wcb_perf_probe.ps1`
  - 调用现有 `C:\wcbclient\wcb_perf_test.exe`。
  - 采集 `Available MBytes`、`Pages/sec`、`Page Reads/sec`、分页文件使用率、磁盘读写延迟、CPU 队列、Chrome/Driver/WCB 进程内存。
  - 输出到 `C:\wind\spider\perf-runs\probe_*`。
- `tools/browser_microbench.py`
  - 使用 `C:\wind\spider\.venv` 中的 Selenium。
  - 直接启动 `C:\wcbclient\GoogleChrome109\wcb_chrome.exe` 和 `wcb_chromedriver.exe`。
  - 只测 Chrome/Driver 冷启动与本地 `data:` 页面加载，用于拆分浏览器生命周期成本和业务页面成本。
- `tools/custom_browser_tpm_probe.py`
  - 自实现浏览器 tpm 探针，不依赖 `wcb_perf_test.exe`。
  - 从 `https://kabushiki.jp/news/flash` 抓取 detail URL。
  - 使用本地 Chrome 109：`C:\wcbclient\GoogleChrome109\wcb_chrome.exe` / `wcb_chromedriver.exe`。
  - 支持三种模式：每条冷启动并清 profile、每条冷启动但复用 profile/cache、每 worker 常驻复用 webdriver。
  - 使用 Windows API 采集相关进程 I/O，避免频繁启动 PowerShell/WMI。

## 当前系统状态

已确认：

- 电源计划已经是高性能。
- Windows Defender 实时防护、OnAccess、BehaviorMonitor 均为关闭；`WinDefend` 服务仍运行。
- VBS/Device Guard 不是当前主要方向，早前检查显示 VBS 未启用。
- `WSearch` 已禁用。
- 为降低测试干扰，已停止 `SysMain`、`DiagTrack`、`UsoSvc`。这些服务当前为 `Stopped`，启动类型仍为 `Automatic`。

注意：测试过程中曾误杀 `WindowsTerminal.exe`。该进程承载交互终端，虽然不是 `codex.exe` 本身，但会导致前端会话异常退出。后续测试不再终止 Terminal/Explorer/RDP 相关进程。

## 关键测试结果

### 独立浏览器微基准

不走业务解析，只启动 Chrome/Driver 并加载本地页面：

| 测试 | 并发 | 次数 | create avg | create p50 | total avg | total p50 |
|---|---:|---:|---:|---:|---:|---:|
| microbench | 1 | 6 | 2.9s | 2.2s | 5.7s | 4.9s |
| microbench | 2 | 10 | 3.3s | 3.5s | 6.5s | 6.8s |

结论：纯 Chrome/Driver 冷启动成本是秒级，不足以单独解释业务 detail 的 40-80 秒耗时。真实耗时主要来自业务页面加载、附件/外链检测、并发下的系统分页和调度等待。

### 业务级探针

| 测试 | 调整 | 吞吐 | avg | p50 | p95 | 资源现象 |
|---|---|---:|---:|---:|---:|---|
| C2/N6 | 普通 | 1.6/min | 57.4s | 44.4s | 104.0s | 短样本受网络超时影响大 |
| C1/N6 | 普通 | 1.6/min | 37.6s | 37.3s | 42.0s | 单条更稳，但吞吐低 |
| C2/N6 | High priority | 2.9/min | 40.1s | 38.1s | 49.0s | 短样本改善，但网络超时更少，存在噪声 |
| C5/N30 | 停止后台服务后 | 4.3/min | 67.1s | 65.9s | 88.1s | Chrome 工作集峰值约 2.25GB，Page Reads/sec avg 927 |
| C5/N30 | High priority | 3.1/min | 81.0s | 72.7s | 134.0s | 变差，不建议作为优化项 |
| C5/N30 | hosts 快速失败 facebook/twitter | 2.9/min | 78.5s | 65.0s | 153.5s | 变差，不建议保留 |
| C3/N20 | 普通 | 3.5/min | 48.0s | 46.6s | 65.0s | Chrome 工作集峰值约 1.28GB，更稳定 |

历史对照：

- 旧 WS2025 B5/N50：3.7/min。
- 关闭/调整 Defender 后 B5/N50：4.8/min。
- 本轮 C5/N30：4.3/min，未超过旧最好结果。

### 自实现浏览器探针

该测试不走 `wcb_perf_test.exe`，只验证浏览器 detail 主页面加载能力；因此不能和生产程序完全等价，但可以拆分浏览器生命周期成本。

| 模式 | 并发/条数 | 成功/失败 | tpm | avg | p50 | p95 | 含义 |
|---|---:|---:|---:|---:|---:|---:|---|
| `cold-clean` | C2/N8 | 6/2 | 3.52 | 19.9s | 17.1s | 28.4s | 每条 detail 新建 Chrome，结束后清 profile/cache |
| `cold-reuse-profile` | C2/N8 | 6/2 | 4.47 | 14.9s | 13.2s | 19.3s | 每条新建 Chrome，但同 worker 复用 profile/cache |
| `warm-reuse-driver` | C2/N8 | 7/1 | 7.05 | 9.7s | 7.6s | 24.2s | 每 worker 常驻一个 Chrome/driver |
| `warm-reuse-driver` | C5/N20 | 16/4 | 9.77 | 17.1s | 18.1s | 24.1s | 5 个常驻 Chrome 并行加载 detail |

结论：

- 复用 profile/cache 有收益，但幅度有限：3.52 -> 4.47 tpm。
- 复用 webdriver/Chrome 常驻收益显著：C2 从 3.52 -> 7.05 tpm；C5 达到 9.77 tpm。
- 这说明 WS2025 并非“系统浏览器模式天然跑不上去”；原程序每条 detail 重建 Chrome 生命周期，是 tpm 低的重要原因。
- 自实现探针没有执行原程序的附件/外链检测，因此 9.77 tpm 是“浏览器主页面加载上限验证”，不是生产可直接承诺的 tpm。

## 重要故障信号

C5 压测后曾出现多条 PowerShell 启动失败：

```text
The paging file is too small for this operation to complete. HRESULT:0x800705AF
Thread failed to start.
```

随后发现 `WindowsTerminal.exe` 一度占用约 1.2GB 工作集。即使不是爬虫进程，它也会在 2GB 机器上严重污染浏览器压测。系统回落后，当前可用内存约 862MB，分页文件使用约 22%。

该信号说明：问题不只是“慢”，而是 C5 浏览器模式在 2GB Server 2025 上会把系统推近资源耗尽边界，导致 Chrome 进程创建失败或管理进程无法创建线程。

## ETW/WPR 证据

为解释“同程序在 WS2016 上没有明显 I/O 问题，但 WS2025 上 I/O 异常高”，采集了一个很小的 WPR trace：

- 场景：`custom_browser_tpm_probe.py --mode cold-clean --concurrency 1 --target-count 2`
- Trace：`C:\wind\spider\perf-runs\wpr_chrome_cold_c1_n2_20260729.etl`
- 摘要：`C:\wind\spider\perf-runs\wpr_chrome_cold_c1_n2_summary.txt`

摘要中的关键事件计数：

| 事件 | 数量 | 含义 |
|---|---:|---|
| `FileIo Read` | 95,978 | Chrome 冷启动和页面加载期间存在大量文件读请求 |
| `DiskIo Read` | 73,853 | 很多文件读没有被缓存吸收，落到了真实磁盘读 |
| `PageFault HardFault` | 68,673 | 大量读与硬缺页相关，说明文件页/映像页不在内存中 |
| `Image Load/Unload` | 1,365 / 1,441 | 短测试也有大量映像加载/卸载 |
| `Microsoft-Antimalware-AMFilter` | 297 | Defender 过滤驱动路径仍有事件，即使实时防护关闭 |

这使解释更完整：同一程序在 WS2016 和 WS2025 都会制造大量 Chrome 冷启动文件访问，但 WS2016 可能更多命中文件缓存、较少触发新版安全/过滤/映像加载路径；WS2025 上这些访问更容易转化为真实 Disk I/O 和 hard fault。因此“程序一样”不矛盾，程序是放大器，OS 版本决定放大后的成本。

## 当前判断

1. **高 I/O 主要来自 Chrome 自身重复冷读，而不是 Defender 进程直接读。** 进程级 I/O 采集显示，`wcb_perf_test.exe` C5/N20 中每个 data Chrome 进程读约 360-528MB，5 个 data Chrome 合计约 2.3GB；`MsMpEng.exe` 读增量约 0MB，`MpDefenderCoreService.exe` 约 0.26MB。
2. **当前程序模型会放大新版 Windows 的 Chrome 文件 I/O 成本。** `sel_driver_loader.py` 会按 policy 复制不同名称的 Chrome exe/driver，并为 policy 建独立 `user-data-dir`、`disk-cache-dir`、`temp-dir`。这会让每批任务都更像“新二进制 + 新 profile 冷启动”，削弱系统文件缓存复用，也更容易触发签名/映像加载/代码完整性路径。
3. **自实现探针证明 tpm 能提升上去。** 在同一台 WS2025、同一个本地 Chrome 109 上，常驻复用 webdriver 后，C5/N20 主页面加载 tpm 达到 9.77，超过 WS2016 报告中的 B5 7.5。这把方向从“系统无法优化”转为“需要减少原程序的浏览器生命周期开销”。
4. **ETW 支持“真实 Disk I/O + hard fault”解释。** C1/N2 冷启动 trace 就出现 73,853 个 DiskIo Read 和 68,673 个 HardFault；这说明 WS2025 上不是单纯逻辑文件请求多，而是大量请求落到了磁盘和硬缺页。
5. **内存压力是放大器，不是唯一根因。** C5 时 Chrome 聚合工作集可超过 2GB，Page Reads/sec 长时间偏高，CPU 队列也很高；但用户确认 WS2016 同样为系统自动管理虚拟内存，因此 pagefile 不作为解释 2016/2025 差距的主方向。
6. **Defender 已不是当前剩余差距的主因，但过滤驱动仍在路径上。** 实时防护已经关闭，`MsMpEng.exe` 进程读增量很小；但 `WdFilter` 仍挂载，WPR 中有 `Microsoft-Antimalware-AMFilter` 事件。因此应做“目录排除项/过滤路径”验证，而不是只看 MsMpEng 进程 I/O。
7. **腾讯云监控 agent 不是主因。** 停止 `BaradAgentSvc`、`StargateSvc`、`tatsvc` 后，C5/N20 从 3.8/min 降到 3.5/min；平均整机读从 11.3MB/s 降到 9.7MB/s，峰值读下降，但 tpm 未提升。`YDService/YDLive` 会自动拉起，未完全停用。
8. **High priority 不是稳定优化。** 短样本看似改善，长样本 C5/N30 明显变差。
9. **hosts 快速失败 facebook/twitter 无效。** 吞吐下降，说明这些外链不是本轮样本主导瓶颈，或附件检测仍有其它等待路径。

## 建议

- 优先验证“复用 Chrome 二进制和 profile/cache 目录”的程序/配置侧优化，而不是继续扩大 pagefile 或调并发。目标是减少每个 Chrome 进程 360-528MB 的重复读。
- 测试前关闭不必要 GUI 和后台程序，但不要终止 `WindowsTerminal.exe`、`explorer.exe`、RDP、`codex.exe`。
- 保持 pagefile 系统自动管理，以对齐 WS2016 对比口径。本机已恢复 `AutomaticManagedPagefile=True`。
- 将 `SysMain`、`DiagTrack`、`UsoSvc` 禁用，减少测试环境后台内存和 I/O 干扰。本机已设置为 `Disabled`。
- 可继续保留 Defender 实时防护关闭作为已验证优化；下一步若要更可控，应测试 Defender 目录排除项，而不是依赖全局关闭。
- 不建议启用进程 High priority，不建议保留 hosts 中的 facebook/twitter 快速失败规则。
- 若要继续追平 WS2016，需要证明“同代码、同站点、同并发”下是否仍受内存限制。当前环境无法加内存时，可继续做：
- A/B：使用固定 `wcb_chrome.exe` / `wcb_chromedriver.exe`，不再为每个 policy 复制新名字。
- A/B：复用 `user-data-dir` / `disk-cache-dir`，或至少保留 warm cache，不在每批任务结束后清理。
- A/B：在原程序中引入每 worker 浏览器池，detail 间复用 webdriver；自实现探针显示这是最大收益来源。
- A/B：Chrome 参数减少后台网络和组件更新：`--disable-background-networking`、`--disable-component-update`、`--disable-features=OptimizationHints,MediaRouter,Translate`。
- ETW/WPR 短 trace，确认 Image Load、File I/O、Code Integrity、hard faults 是否集中在 Chrome 冷启动和 profile/cache 目录。

## 已应用的优化项

| 优化项 | 当前状态 | 是否需要重启 | 预期作用 |
|---|---|---:|---|
| Defender 实时防护关闭 | 已关闭 | 否 | 减少文件实时扫描开销；此前 B5 从 3.7/min 提升到 4.8/min |
| `SysMain` 禁用 | 已应用 | 否 | 减少后台预取和内存压力 |
| `DiagTrack` 禁用 | 已应用 | 否 | 减少遥测后台活动 |
| `UsoSvc` 禁用 | 已应用 | 否 | 避免更新编排服务在测试期间启动 |
| pagefile 系统自动管理 | 已恢复 | 可能需要重启完全生效 | 对齐 WS2016 测试口径 |
| 停止 `BaradAgentSvc`/`StargateSvc`/`tatsvc` | 已测试 | 否 | 未提升 tpm，不作为主要优化 |
| 复用 Chrome 二进制名称 | 待验证 | 否 | 预期减少新版 Windows 上映像加载/签名校验/文件缓存冷读 |
| 复用 Chrome profile/cache | 已用自实现探针验证 | 否 | C2/N8 从 3.52 -> 4.47 tpm，收益有限但存在 |
| 每 worker 常驻复用 webdriver | 已用自实现探针验证 | 否 | C2/N8 从 3.52 -> 7.05 tpm；C5/N20 达 9.77 tpm |

当前不是“没有优化方法”，而是系统开关层面的收益已经有限。剩余大差距更可能来自程序当前的 Chrome 生命周期模型在 WS2025 上放大了冷启动 I/O：每个 policy 复制二进制、独立 profile/cache、结束后清理。下一步应优先验证这些 I/O 复用优化。

## 临时变更记录

- 已新增 `tools/run_wcb_perf_probe.ps1`。
- 已新增 `tools/run_wcb_io_probe.ps1`。
- 已新增 `tools/browser_microbench.py`。
- 已新增 `tools/custom_browser_tpm_probe.py`。
- 曾向 hosts 添加 facebook/twitter 快速失败规则，测试后已恢复备份并刷新 DNS。
- 已停止并禁用 `SysMain`、`DiagTrack`、`UsoSvc`。
- 曾短暂将 pagefile 改为固定大小；根据对比口径要求，已恢复系统自动管理。
- 曾生成 `C:\wcbclient\GoogleChrome109\bench_*.exe` 微基准临时二进制，已删除。

## 2026-07-29 补充：通道隔离约束与后续验证方向

用户已明确：同一个 `policyId` 表示一个通道，通道内代理配置相同；为了实现通道隔离和进程管理，当前按 policy 复制/命名 Chrome 与 chromedriver 是必要机制。因此后续优化不应把“取消 per-policy Chrome 复制”作为主方案。

需要保留的约束：

- 继续使用 `chrome_common_<policy>_data.exe`、`chrome_common_<policy>_data_driver.exe` 等通道级进程名。
- 继续保持每个 policy 独立 `user-data-dir`、`disk-cache-dir`、`temp-dir`，避免代理、Cookie、下载目录、任务状态串扰。
- 继续允许按 policy 精确清理/终止异常残留进程。

真正需要验证的是生命周期粒度：通道隔离并不要求每条 detail 都销毁 Chrome。当前 `Crawler_Common_Browser.getDetail()` 每次执行都会初始化浏览器；结束时 `__release_detail_resources()` 调用 `_kill_chrome_task_pid(policy, 'detail')`，该方法会 `WebDriver.quit()` 并清理 `chrome_cache\temp_<policy>`。下一条 detail 又在 `_init_web_driver()` 里先 `force_kill=True` 再重新创建 Chrome。这会把每条 detail 都放大成“通道 Chrome 冷启动 + profile/cache 重建 + 镜像加载 + hard fault + Defender filter 路径检查”。

需要注意：detail 集中连续执行是当前压测程序的行为，不等同于生产调度。真实链路中 list 任务生成多个 detail 任务后返回爬虫服务端，detail 可能被分配到不同云主机执行；因此“每个 worker/policy 常驻复用 webdriver”在压测中收益明显，但在生产场景中可复用窗口很小，不能作为主优化方案。

因此该 A/B 的定位应调整为“证明 Chrome 冷启动生命周期是 I/O 放大器”，而不是直接作为生产改造建议。生产侧更现实的优化目标是：在保留每条 detail 用完即销毁的模型下，降低 WS2025 对 Chrome 冷启动、profile/cache 创建、镜像加载、安全过滤和 hard fault 的系统级成本。

后续建议优先验证：

1. Defender/安全过滤路径：对 `C:\wcbclient\GoogleChrome109`、`C:\wcbclient\chrome_cache`、`C:\wcbclient\wcb_comspnew_temp`、任务下载目录增加排除项，并用 WPR/进程 I/O 对比 `DiskIo Read`、`HardFault`、`AMFilter` 变化。
2. Chrome 冷启动文件集预热：在压测前顺序读取 Chrome 109 目录下 exe/dll/pak/dat 等常用文件，验证能否让 WS2025 更多命中文件缓存，接近 WS2016 行为。
3. Chrome/profile/cache 路径位置：验证将 `chrome_cache` 和任务下载临时目录放到低延迟本地盘/内存盘/排除扫描目录后，是否降低 Page Reads/sec 和 Avg Disk sec/Read。
4. OS 图形/桌面路径：验证 headed Chrome 在 Server 2025 上是否受 DWM/GPU/软件渲染影响，比较 `--disable-gpu`、固定窗口大小、不 `maximize_window()` 等配置对冷启动和 page load 的影响。
5. 镜像加载/代码完整性路径：用短 WPR trace 对比优化前后 `Image Load/Unload`、Code Integrity、安全过滤事件，确认 WS2025 相比 WS2016 的差异是否主要发生在镜像加载阶段。

不再把“每 worker 常驻 webdriver”列为主生产建议；它只用于解释和证明生命周期成本。

原先集中压测场景下可验证的 A/B 是：

1. 每个 worker/policy 保留一套独立 Chrome 二进制名、driver 名和 profile/cache。
2. 在同一 worker/policy 内复用一个常驻 webdriver 处理多条 detail。
3. 每条 detail 只清理任务下载临时目录，不清理通道级 profile/cache。
4. worker 结束或异常时再按 policy 做最终 `quit/kill/cache cleanup`。

这个方向可以解释“同样程序为何 WS2016 没明显 I/O，而 WS2025 有”：同样的每条 detail 冷启动访问模式在 WS2025 上被 ETW 证明转化为大量真实 `DiskIo Read`、`PageFault HardFault` 和 `Image Load/Unload`；WS2016 可能更多命中文件缓存、较少触发新版安全/镜像加载路径成本。程序是放大器，OS 版本决定该冷启动模式被放大后的真实成本。

### Defender 排除项与 Chrome 文件预热验证

已按冷启动生产模型做两轮 C5/N20 原程序 probe：

| 场景 | tpm | avg | p95 | Avg Page Reads/sec | Avg Disk Read | 结论 |
|---|---:|---:|---:|---:|---:|---|
| 基线参考 | 3.8/min | 67.3s | 123.8s | 约 1010 | 11.32MB/s | Chrome data 进程读量约 360-528MB/进程 |
| Defender 目录排除 + DisableIOAVProtection | 3.7/min | 65.0s | 100.1s | 764 | 9.88MB/s | I/O 指标下降，但 tpm 未实质提升 |
| Defender 排除基础上预热 Chrome 109 文件集 | 3.2/min | 73.0s | 106.2s | 470 | 10.14MB/s | 文件预热未提升 tpm，Chrome data 读量仍约 359-544MB/进程 |
| 清理历史 `perf_browser` 复制件后 | 4.1/min | 68.4s | 91.8s | 1018 | 11.03MB/s | 吞吐小幅回升，但 hard fault/I/O 压力仍高 |

应用的 Defender 测试项：

- `DisableRealtimeMonitoring=True`
- `DisableIOAVProtection=True`
- 排除路径：`C:\wcbclient\GoogleChrome109`、`C:\wcbclient\chrome_cache`、`C:\wcbclient\wcb_comspnew_temp`、`C:\wcbclient\Data`、`C:\wcbclient\Log`

阶段性判断：

- Defender/IOAV 过滤会影响 I/O 指标，但不是当前 WS2025 与 WS2016 差距的主因。
- 预热 Chrome 安装目录不能解决问题，说明高成本不只是 exe/dll/pak 文件冷缓存；还包括每条 detail 的 profile/cache 创建、页面资源、Chrome 子进程工作集、镜像加载和 2GB 内存下的硬缺页压力。
- 本机 `GoogleChrome109` 目录曾残留 182 个 `chrome_common_perf_browser*` 测试复制件，占 1326.72MB；已删除。该项会污染测试环境和预热实验，但清理后 tpm 仅到 4.1/min，不能解释主要差距。
- 已禁用 Google Update 计划任务和 Edge Update 服务，用于降低后台更新噪声；这类噪声不是当前主瓶颈。
- 继续优化应优先找出 hard fault 和 DiskIo 的具体路径分布，而不是继续扩大 pagefile 或仅靠预热安装目录。

## 2026-07-29 复核 `C:\wcbclient\perf-output-2025`

复核对象：

- `C:\wcbclient\perf-output-2025\perf_windows.csv`
- 同目录下 `browser-*summary*.csv`、`request-*summary*.csv`

`perf_windows.csv` 字段包含整体 CPU、内存、磁盘读写字节、网络、crawler/browser/driver 进程数和内存；不包含 `Page Reads/sec`、hard fault、磁盘延迟。因此该数据能判断吞吐型 I/O 是否异常，但不能单独证明分页/硬缺页根因。

按 run_id 时间窗口对齐后的结果：

| 模式 | 并发 | tpm | avg | p95 | Avg Disk Read | P95 Disk Read | Max Disk Read | CPU avg/p95 | Mem p95 | Browser mem max |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| browser | 2 | 2.6/min | 42.9s | 81.8s | 2.77MB/s | 15.61MB/s | 51.65MB/s | 52.3% / 100% | 85.3% | 909MB |
| browser | 3 | 2.6/min | 56.7s | 150.9s | 6.86MB/s | 35.20MB/s | 274.40MB/s | 56.9% / 100% | 86.4% | 1339MB |
| browser | 5 | 3.7/min | 72.0s | 125.9s | 14.60MB/s | 49.11MB/s | 158.44MB/s | 79.9% / 100% | 92.1% | 2147MB |
| browser | 10 | 3.7/min | 145.6s | 233.8s | 37.22MB/s | 153.07MB/s | 435.83MB/s | 90.5% / 100% | 95.3% | 2660MB |
| request | 1 | 10.2/min | 5.9s | 10.2s | 0.14MB/s | 0.09MB/s | 15.36MB/s | 7.7% / 15.1% | 83.7% | 0MB |
| request | 2 | 16.8/min | 5.1s | 9.6s | 0.09MB/s | 0.36MB/s | 3.53MB/s | 9.4% / 18.2% | 84.2% | 0MB |
| request | 3 | 30.6/min | 5.7s | 10.8s | 0.06MB/s | 0.26MB/s | 1.58MB/s | 11.9% / 21.4% | 83.3% | 0MB |

汇总判断：

- browser 窗口整体 Avg Disk Read 为 11.48MB/s，P95 49.76MB/s，Max 435.83MB/s。
- request 窗口整体 Avg Disk Read 为 0.11MB/s，P95 0.26MB/s，Max 15.36MB/s。
- I/O 明显是 browser 模式特有现象，并且随 browser 并发升高而升高：C2 2.77MB/s、C3 6.86MB/s、C5 14.60MB/s、C10 37.22MB/s。
- 高读样本通常伴随 CPU 100%、内存 87%-95%、大量 browser 子进程和高 browser 工作集。例如 C10 高读样本平均 CPU 99.7%、内存 92.5%、browser mem 1882MB、browser proc 89。
- 但单条 detail 耗时与该 detail 时间窗口内平均磁盘读速率相关性很低：C2 约 0.005、C3 约 -0.021、C5 约 0.127、C10 约 0.072。

结论：历史数据确认 I/O 是真实异常信号，且高度集中在 browser 模式；但这些数据不能证明“磁盘 I/O 本身就是 tpm 低的唯一根因”。更合理的解释是 browser 并发导致 Chrome 进程数、工作集、CPU、内存压力和真实磁盘读一起上升；I/O 需要继续作为 hard fault/内存压力/Chrome 冷启动路径的症状排查，而不是单独作为磁盘带宽瓶颈处理。

## 2026-07-29 无人值守测试：方向修正

本轮按“先判定 I/O 是否主因，再做 A/B”的方式继续测试。新增：

- `tools/run_src_io_probe.ps1`：用源码 `src/perf_test_runner.py` 执行同一压测链路，并采集进程 I/O 与系统 counters。
- `tools/run_wcb_io_probe.ps1` 新增可选 `-ConfigPath`，默认行为不变。
- `perf-runs/browser-jp-no-autoattachment.json`：只将测试配置中的 `autoAttachment` 改为 `false`。
- 源码增加测试开关，默认不改变生产行为：
  - `WCB_ATTACHMENT_SAME_DOMAIN_ONLY=1`
  - `WCB_ATTACHMENT_EXTENSION_ONLY=1`
  - `WCB_CHROME_DISABLE_GPU=1`
  - `WCB_CHROME_WINDOW_SIZE=1280,900`
  - `WCB_SKIP_MAXIMIZE=1`

### 完整基线

| 场景 | 执行链路 | 并发/数量 | tpm | avg | p50 | p95 | Avg Page Reads/sec | Avg Disk Read | Avg Queue | 关键现象 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 原始配置 | `wcb_perf_test.exe` | C5/N20 | 2.3/min | 91.9s | 75.2s | 175.6s | 343.6 | 4.08MB/s | 13.1 | 每个 Chrome data 读约 510-569MB；CPU 队列峰值 125 |
| 原始配置 | `wcb_perf_test.exe` | C2/N20 | 1.9/min | 57.9s | 39.7s | 153.8s | 195.5 | 1.70MB/s | 7.1 | 两个 Chrome data 各读约 1.08-1.17GB |

关键日志：

- 每轮 20 条 detail 均出现 `facebook.com`、`twitter.com` 链接探测。
- `web_attachment_detector.py` 每条 detail 的附件检测耗时约 14-35s。
- 原始 C5/N20 中 `facebook.com`/`twitter.com` 各 20 次，`ConnectTimeout` 29 次，`Read timed out` 19 次。

这说明本轮慢任务不能继续优先解释为 I/O；自动附件/外链探测超时是更直接的耗时来源。

### A/B：关闭自动附件探测

| 场景 | 执行链路 | 并发/数量 | tpm | avg | p50 | p95 | Avg Page Reads/sec | Avg Disk Read | 超时现象 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| `autoAttachment=false` | `wcb_perf_test.exe` | C2/N20 | 3.5/min | 28.1s | 22.1s | 38.3s | 44.5 | 1.29MB/s | facebook/twitter/ConnectTimeout 均为 0 |
| `autoAttachment=false` | `wcb_perf_test.exe` | C5/N20 | 5.3/min | 38.5s | 32.5s | 63.0s | 119.5 | 3.28MB/s | facebook/twitter/ConnectTimeout 均为 0 |

对比原始配置：

- C2：1.9/min -> 3.5/min，p95 153.8s -> 38.3s。
- C5：2.3/min -> 5.3/min，p95 175.6s -> 63.0s。
- Chrome data 进程读量从数百 MB/进程降到约 60-106MB/进程。

该结果说明：原始高 I/O 很大一部分是自动附件探测导致的浏览器/网络/页面处理链路放大结果，而不是单纯磁盘瓶颈。

### A/B：保留 autoAttachment，但只用扩展名快速识别附件

`WCB_ATTACHMENT_SAME_DOMAIN_ONLY=1` 仅过滤外域链接，效果不好：facebook/twitter 消失，但站内未知链接 HEAD/GET 仍导致每条附件检测约 10-27s，C2/N20 仅 1.5/min。

`WCB_ATTACHMENT_EXTENSION_ONLY=1` 禁用未知链接 HEAD/GET，只保留 URL 扩展名识别：

| 场景 | 执行链路 | 并发/数量 | tpm | avg | p50 | p95 | Avg Page Reads/sec | Avg Disk Read | 关键现象 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| extension-only | 源码 | C2/N20 | 3.0/min | 37.8s | 24.1s | 136.2s | 53.6 | 0.77MB/s | 附件检测耗时均为 0s，但有 2 个 webdriver localhost 120s 超时 |
| extension-only + 图形参数 | 源码 | C2/N20 | 3.7/min | 29.0s | 22.7s | 48.7s | 60.7 | 1.13MB/s | 仍有 1 个 webdriver localhost 120s 超时 |
| extension-only + 图形参数 | 源码 | C5/N20 | 4.7/min | 49.0s | 38.7s | 139.6s | 74.5 | 1.65MB/s | 有 3 个 webdriver localhost 120s 超时 |

图形参数：

- `--disable-gpu`
- `--window-size=1280,900`
- 跳过 `maximize_window()`

阶段性判断：

1. I/O 确实是 browser 模式异常信号，但不是当前最优先的根因。
2. 自动附件探测对所有未知链接做 HEAD/GET，是本轮最明确的主耗时来源；它会引入 facebook/twitter/站内链接超时，并放大 Chrome 进程、I/O 和系统等待。
3. 只按扩展名识别附件能把附件检测耗时降到 0s，并显著降低 Page Reads 与 Disk Read。
4. 剩余长尾主要来自 Selenium 与本地 chromedriver 通信超时：`HTTPConnectionPool(host='localhost', ...): Read timed out (read timeout=120)`。这更像 Chrome/driver 会话卡死或图形/进程调度问题，不是磁盘 I/O。
5. 下一步优化优先级应调整为：
   - 优先改造 autoAttachment：默认不要对所有普通链接做 HEAD/GET；仅对扩展名、明显下载文本、配置允许域或同域白名单做探测。
   - 保留图形参数 A/B：`--disable-gpu`、固定窗口、跳过 maximize 有收益。
   - 对 webdriver localhost 120s 卡死做单独定位，必要时缩短 Selenium 命令超时并在卡死时快速重启当前 detail。
   - I/O 降为伴随指标，继续监控 Page Reads/Disk Read，但不再作为唯一主线。

## 2026-07-30 系统安全精简记录

基于“Server 2025 默认常驻占用高，2GB 云主机更容易放大 browser 模式长尾”的假设，新增可复用安全精简脚本：

- `tools/apply_windows_crawler_safe_tuning.ps1`
- 详细记录：`docs/windows-server-crawler-safe-tuning.md`

安全边界：

- 不修改 RDP：`TermService`、`UmRdpService`、`SessionEnv`
- 不修改核心网络：`Dhcp`、`Dnscache`、`NlaSvc`、`BFE`、`mpssvc`
- 不修改远程/共享：`LanmanServer`、`LanmanWorkstation`、`WinRM`
- 不修改云厂商 agent：`YDService`、`YDLive`、`BaradAgentSvc`、`StargateSvc`、`tatsvc`
- 不修改防火墙、路由、网卡、DNS、hosts、pagefile

本机已执行 Level 1：

```text
C:\wind\spider\perf-runs\windows_crawler_safe_tuning_20260730_101238\
```

主要动作：

- 停止/禁用低风险 UI、诊断、通知、兼容性、后台维护服务：`AudioSrv`、`DPS`、`PcaSvc`、`ShellHWDetection`、`Themes`、`TrkWks`、`UALSVC`、`WerSvc`、`WpnService` 等。
- 禁用低风险计划任务：Application Experience、CEIP、Diagnosis、DiskCleanup、DiskFootprint、WinSAT、Server Manager、Shell IndexerAutomaticMaintenance、Bluetooth/Printing 清理任务等。
- 部分 per-user 服务因系统限制未能设置为 Disabled，未用注册表强改，避免影响登录会话。

应用后复核：

- RDP 相关服务仍 Running。
- `Dhcp`、`Dnscache`、`BFE`、`mpssvc`、`LanmanServer`、`LanmanWorkstation`、`WinRM` 仍 Running。
- `YDService`、`YDLive` 仍 Running。
- `kabushiki.jp`、`info.kabushiki.jp`、`member.kabushiki.jp` TCP 443 均正常。

该精简用于降低系统底噪和内存压力，不作为单独根因结论。后续需通过相同 C5/N20 压测验证其对 tpm、p95、Page Reads/sec、CPU Queue、webdriver 120s timeout 的实际影响。

### Level 1 精简后对比与归因修正

精简后使用相同 `wcb_perf_test.exe`、原始 `C:\wcbclient\test\browser-jp.json`、C5/N20 重新压测：

```text
C:\wind\spider\perf-runs\io_probe_c5_n20_20260730_105447\
```

与精简前最近 C5/N20 基线对比：

| 指标 | 精简前 | 精简后 | 变化 |
|---|---:|---:|---:|
| tpm | 2.3/min | 4.4/min | +91% |
| avg | 91.9s | 62.9s | -29.0s |
| p50 | 75.2s | 60.3s | -14.9s |
| p95 | 175.6s | 86.1s | -89.5s |
| max | 185.4s | 90.6s | -94.8s |
| Avg Available MB | 528.2 | 472.0 | 下降 |
| Min Available MB | 136 | 147 | 略升 |
| Avg Page Reads/sec | 343.6 | 1186.2 | 上升 |
| Avg Disk Read | 4.08MB/s | 11.32MB/s | 上升 |
| Avg Processor Queue | 13.1 | 48.4 | 上升 |
| Chrome data 平均读量 | 537.3MB/进程 | 341.3MB/进程 | 下降 |
| `HTTPConnectionPool(localhost)` 120s timeout | 3 | 0 | 消失 |
| `ConnectTimeout` | 29 | 25 | 略降 |
| `Read timed out` | 19 | 4 | 明显下降 |
| 附件检测平均耗时 | 21.6s | 22.3s | 基本持平 |
| 附件检测最大耗时 | 35s | 42s | 略升 |

短样本解读：

- Level 1 系统精简后，同样原始配置的 tpm 和 p95 明显改善，尤其是 webdriver localhost 120s 长尾从 3 次降到 0。
- 系统级 I/O counters 没有下降，反而上升；因此这轮提升不能解释为“磁盘 I/O 被优化了”。
- Chrome data 进程平均读量下降，说明单个浏览器生命周期内的重复读有所减少，但系统整体读更高，可能与更短时间内完成更多任务、采样窗口不同、缓存/页面资源活动集中有关。
- `Read timed out` 从 19 次降到 4 次，网络等待形态也有改善；但 `facebook.com`/`twitter.com` 仍各出现 20 次，`autoAttachment` 平均耗时仍约 22s，说明自动附件探测仍是确定性耗时来源。

随后用户使用原始 `wcb_perf_test.exe`、原始 `browser-jp.json`、C5/N50 重新压测，结果如下：

```text
C:\wcbclient\perf-output\browser-5-summary_20260730T030918Z_0b8c212b.csv
throughput_per_min=5.3, avg=54.4s, p50=53.2s, p95=66.0s, max=87.7s
```

与 2026-07-28 关闭/调整主动防御后的可比 C5/N50 结果对比：

```text
C:\wcbclient\perf-output\browser-5-summary_20260728T114125Z_381112fc.csv
throughput_per_min=4.8, avg=56.0s, p50=49.3s, p95=111.3s, max=171.5s
```

归因修正：

- C5/N50 的吞吐只从 4.8/min 到 5.3/min，提升幅度小，不能证明 Level 1 服务精简是 TPM 提升主因。
- Level 1 更合理的定位是“降低后台噪声、减少偶发长尾”的安全基线；它可能改善 p95/max，但不是解释 Server 2025 与 Server 2016 差距的充分证据。
- 当前已确认的主要收益仍应归因于此前关闭/调整主动防御、Defender 实时/IOAV/OnAccess 路径，以及 `autoAttachment` 未知链接探测策略。
- 后续若继续做系统侧优化，应优先验证安全过滤路径、Defender 排除项、计划任务/签名更新是否在测试窗口介入；不应继续扩大到网络、RDP、云 agent 或 pagefile。

### 2026-07-30 带系统采集的 C5/N50 复测

按用户要求，使用 `tools/run_wcb_io_probe.ps1` 重新执行原始 `wcb_perf_test.exe`、原始 `browser-jp.json`、C5/N50，并同步采集 CPU、内存和 I/O：

```text
C:\wind\spider\perf-runs\io_probe_c5_n50_20260730_113247\
```

summary：

```text
run_id=20260730T033252Z_3ff36764
success=50, fail=0
total_duration=731.1s
throughput_per_min=4.1
avg=60.2s, p50=55.1s, p90=84.7s, p95=115.1s, max=182.4s
```

系统 counters：

| 指标 | avg | p95 | max |
|---|---:|---:|---:|
| Available MB | 545.8 | 905 | 1067 |
| Pages/sec | 2550.2 | 10529.7 | 38109.7 |
| Page Reads/sec | 973.6 | 1708.7 | 23771.5 |
| Disk Read Bytes/sec | 5.60MB/s | 27.59MB/s | 104.29MB/s |
| Disk Write Bytes/sec | 1.27MB/s | 2.44MB/s | 39.28MB/s |
| Processor Queue Length | 36.2 | 100 | 166 |

日志信号：

- `facebook.com`：50 次。
- `twitter.com`：50 次。
- `ConnectTimeout`：69 次。
- `Read timed out`：34 次。
- `ConnectionResetError`：16 次。
- `HTTPConnectionPool(host='localhost', ... read timeout=120)`：2 次。
- 50 条 detail 均为“检测到 0 个附件”；附件检测平均 20.3s，p50 16s，p90 30s，p95 38s，max 51s。

进程 I/O：

- 主要读量集中在 5 个 policy 对应的 Chrome `*_data.exe` 进程族。
- 5 个 data 进程族合计读量约 5.0GB；单个 Chrome 子进程常见读量约 110-123MB。
- `wcb_perf_test.exe` 约 107MB read / 127.5MB write。
- `YDService.exe` 约 4.4MB read / 18MB write。
- `MsMpEng.exe`、`MpDefenderCoreService.exe` 在该采集口径下读写增量约 0。

观察：

- 该轮 4.1/min 明显低于用户同日手跑 C5/N50 的 5.3/min，说明带采集脚本运行和当时系统瞬时状态会放大长尾；该轮不应直接作为“Level 1 失效”的唯一证据。
- 但资源曲线仍确认 C5 浏览器模式在 2GB Server 2025 上会出现明显硬缺页、磁盘读和 CPU 调度队列压力。
- 最慢的 task 13/14 分别耗时 182.4s 和 179.5s，均命中 Selenium 到本地 chromedriver 的 120s ReadTimeout，随后重试成功；这类长尾直接拉低本轮 TPM。
- 安全进程自身没有表现为大量直接读盘；如果主动防御影响性能，更可能发生在文件系统过滤驱动/行为监控路径，而不是 `MsMpEng.exe` 或 `YDService.exe` 用户态进程大量 I/O。
- 当前仍应把 `autoAttachment` 未知链接探测、webdriver localhost 120s 长尾、以及安全过滤路径作为三条主线；单纯继续关闭普通后台服务的收益证据不足。

### 2026-07-30 C5/N50 关闭 autoAttachment 复测

使用仅关闭 `autoAttachment` 的配置重新执行 C5/N50，并同步采集 CPU、内存和 I/O：

```text
C:\wind\spider\perf-runs\browser-jp-no-autoattachment.json
C:\wind\spider\perf-runs\io_probe_c5_n50_20260730_131714\
```

summary：

```text
run_id=20260730T051720Z_462221cf
success=50, fail=0
total_duration=393.4s
throughput_per_min=7.6
avg=32.1s, p50=28.2s, p90=36.2s, p95=42.6s, max=147.9s
```

与同日原始配置、同样采集方式的 C5/N50 对比：

| 场景 | tpm | avg | p50 | p95 | max | localhost 120s timeout | ConnectTimeout | facebook/twitter |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 原始配置 | 4.1/min | 60.2s | 55.1s | 115.1s | 182.4s | 2 | 69 | 50/50 |
| `autoAttachment=false` | 7.6/min | 32.1s | 28.2s | 42.6s | 147.9s | 1 | 0 | 0/0 |

系统 counters 对比：

| 指标 | 原始配置 avg/p95/max | `autoAttachment=false` avg/p95/max |
|---|---:|---:|
| Available MB | 545.8 / 905 / 1067 | 586.0 / 946 / 1015 |
| Pages/sec | 2550.2 / 10529.7 / 38109.7 | 859.1 / 5451.7 / 11364.6 |
| Page Reads/sec | 973.6 / 1708.7 / 23771.5 | 117.2 / 400.8 / 3685.5 |
| Disk Read Bytes/sec | 5.60 / 27.59 / 104.29 MB/s | 3.33 / 16.60 / 48.87 MB/s |
| Disk Write Bytes/sec | 1.27 / 2.44 / 39.28 MB/s | 2.66 / 4.28 / 69.95 MB/s |
| Processor Queue Length | 36.2 / 100 / 166 | 39.3 / 151 / 205 |

进程 I/O：

- 原始配置：5 个 Chrome data 进程族合计读量约 5.0GB。
- `autoAttachment=false`：5 个 Chrome data 进程族合计读量约 0.69GB。
- `MsMpEng.exe`、`MpDefenderCoreService.exe` 在两轮中用户态读写增量均约 0。
- `YDService.exe` 两轮读量均约 4MB 级别。

判断：

- 关闭 `autoAttachment` 后，吞吐从 4.1/min 提升到 7.6/min，已经达到或超过此前报告的 Server 2016 B5 量级；这证明当前 Server 2025 并非“浏览器模式无论如何跑不上去”。
- `autoAttachment` 不只是引入 facebook/twitter/站内链接等待，它还显著放大 Chrome 进程读盘和 Page Reads/sec：Chrome data 读量约从 5.0GB 降到 0.69GB，Page Reads/sec 平均值约从 973.6 降到 117.2。
- 由于 Server 2016 上同样存在 `autoAttachment`，不能把它简单定义为 2016/2025 差异的唯一根因；更准确的说法是：`autoAttachment` 是程序层放大器，Server 2025 的安全过滤、Chrome 冷启动、内存硬缺页、网络失败模式会把该放大器的成本表现得更严重。
- 即使关闭 `autoAttachment`，仍出现 1 次 Selenium 到本地 chromedriver 的 120s ReadTimeout，说明 webdriver 卡死是另一条独立长尾，需要继续单独定位。

### 2026-07-30 源码 runner 卡住与 taskkill/WMI 异常

为了比较 `extension-only` 与 `autoAttachment=false`，尝试使用源码 `perf_test_runner.py` 执行 C5/N50。中间出现“看不到 Chrome 启动”的卡住现象。复核后发现：

- runner 日志停在 `获取列表开始 taskId:1`，尚未进入 `list任务1 打开地址`。
- 代码路径显示 `getList()` 后会先调用 `_init_web_driver('list')`，而 `_init_web_driver()` 第一行是 `_kill_chrome_task_pid(..., force_kill=True)`。
- `_kill_chrome_task_pid()` 会依次调用 `TaskKiller.kill_process_by_name()`，最终执行 `taskkill /F /IM <process>.exe`。
- 本机当时直接执行 `taskkill /F /IM chrome.exe`、`taskkill /F /IM not_exist_short.exe`、以及长 `chrome_common_*` 进程名均超过 5s 不返回，被测试脚本 kill 掉。
- `Get-CimInstance Win32_Service` 也出现超时；说明 WMI/CIM/进程管理路径当时存在阻塞。原采集脚本每轮使用 `Get-CimInstance Win32_Process` 采集进程 I/O，可能放大该问题。

为继续测试，新增仅测试用开关，默认生产行为不变：

- `WCB_SKIP_INIT_TASKKILL=1`：源码 runner 初始化浏览器前跳过强制 `taskkill`。使用前必须确认无残留 `chrome/chromedriver/wcb/python`。
- `tools/run_src_io_probe.ps1 -SkipProcessIo`：跳过 WMI 进程 I/O 采集，仅保留系统 counters。

该发现本身也可能解释一部分 Server 2025 长尾：当前程序高度依赖 `taskkill` 做每条任务前后的进程清理；一旦 Windows 进程管理/WMI/安全过滤路径抖动，Chrome 尚未启动前就可能被阻塞。

### 2026-07-30 源码 C5/N50 可比测试：no-autoAttachment vs extension-only

为避免 `taskkill`/WMI 干扰，以下两轮均使用：

```text
-ChromeGraphicsTuned -SkipInitTaskkill -SkipProcessIo
```

测试前后均确认无残留浏览器进程。

#### 源码 no-autoAttachment + 图形参数

```text
C:\wind\spider\perf-runs\io_probe_src_baseline_gfx_c5_n50_20260730_142255\
```

summary：

```text
throughput_per_min=7.0
avg=36.4s, p50=30.8s, p90=39.9s, p95=118.5s, max=144.9s
success=50, fail=0
```

日志：

- `HTTPConnectionPool(host='localhost' ... read timeout=120)`：3 次。
- `ConnectTimeout`：0。
- `facebook.com` / `twitter.com`：0。
- `web_attachment_detector`：0。
- `Out of memory`：0。

系统 counters：

| 指标 | avg | p95 | max |
|---|---:|---:|---:|
| Available MB | 506.2 | 834 | 1026 |
| Pages/sec | 1383.8 | 4741.4 | 34075.2 |
| Page Reads/sec | 123.0 | 497.6 | 3606.2 |
| Disk Read Bytes/sec | 4.19MB/s | 15.86MB/s | 111.78MB/s |
| Disk Write Bytes/sec | 2.10MB/s | 3.37MB/s | 59.06MB/s |
| Processor Queue Length | 48.8 | 143 | 193 |

#### 源码 extension-only + 图形参数

```text
C:\wind\spider\perf-runs\io_probe_src_ext_only_gfx_c5_n50_20260730_143119\
```

summary：

```text
throughput_per_min=5.1
avg=40.6s, p50=30.4s, p90=99.6s, p95=101.6s, max=140.9s
success=50, fail=0
```

日志：

- `HTTPConnectionPool(host='localhost' ... read timeout=120)`：1 次。
- `ConnectTimeout`：0。
- `facebook.com` / `twitter.com`：0。
- `web_attachment_detector`：100 行；50 条均 `检测到0个附件`，耗时 0s。
- `Out of memory`：0。

系统 counters：

| 指标 | avg | p95 | max |
|---|---:|---:|---:|
| Available MB | 555.4 | 789 | 940 |
| Pages/sec | 1057.8 | 5486.8 | 30533.3 |
| Page Reads/sec | 89.8 | 410.5 | 3124.6 |
| Disk Read Bytes/sec | 3.76MB/s | 20.62MB/s | 114.10MB/s |
| Disk Write Bytes/sec | 0.87MB/s | 2.78MB/s | 32.88MB/s |
| Processor Queue Length | 30.3 | 111 | 172 |

判断：

- 在可比源码链路下，`autoAttachment=false` 为 7.0/min，`extension-only` 为 5.1/min；`extension-only` 清除了外链超时和附件探测等待，但仍比完全关闭附件框架慢。
- `extension-only` 中 `web_attachment_detector` 仍被调用，每条 detail 进入检测框架后快速返回 0 个附件；这说明仅清空未知链接 HEAD/GET 还不等同于完全关闭附件处理路径。
- 两轮 Page Reads/sec 都远低于原始 autoAttachment 配置，说明未知链接探测仍是 I/O/硬缺页放大器；但两轮仍有 webdriver localhost 120s 长尾，说明 Chrome/driver 卡死是独立问题。
- 目前若追求 TPM，`autoAttachment=false` 最强；若必须保留附件能力，`extension-only` 还不够，需要进一步把“无候选附件时跳过整个附件检测/保存流程”，而不只是跳过未知链接 HEAD/GET。

## 2026-07-30 `taskkill` 卡住根因定位

用户在 Windows Server 2016、2022 上验证 `taskkill` 不会卡住；本机 Server 2025 会卡。该问题与爬虫直接相关，因为当前浏览器初始化和释放路径依赖 `taskkill` 清理 `chrome_common_<policy>_*` 进程。

### 现象

本机上：

```text
taskkill /?                         约 369ms 正常返回
taskkill /F /PID 999999             > 5s 不返回
taskkill /F /IM not_exist_short.exe > 5s 不返回
taskkill /F /IM chrome.exe          > 5s 不返回
```

挂起的 `taskkill.exe`：

```text
CPU≈0
主线程 WaitReason=LpcReply
加载模块包含 wbemprox.dll、fastprox.dll、wbemsvc.dll、Winsta.dll、MpOav.dll
```

含义：

- `taskkill.exe` 文件本身正常，帮助信息能快速返回。
- 只要进入实际进程查询/终止逻辑，就进入 LPC/RPC 等待。
- 模块列表证明 `taskkill` 使用了 WMI COM provider 路径查询 `Win32_Process`。

### WMI 证据

WMI Activity 日志记录了与挂起 `taskkill` PID 对应的查询：

```text
IWbemServices::ExecQuery - root\cimv2 :
SELECT __PATH, ProcessId, CSName, Caption, SessionId, ThreadCount,
WorkingSetSize, KernelModeTime, UserModeTime, ParentProcessId
FROM Win32_Process
WHERE ProcessId = 999999
```

错误码：

```text
0x80041032  调用被取消
0x80041033  WMI quota/限流相关错误
0x800706BE  RPC 调用失败
```

同时 `Get-WmiObject Win32_Process` 会超时，而 `Get-CimInstance Win32_Process` 在部分时刻可正常返回。WMI repository 校验结果：

```text
WMI repository is consistent
```

因此这不是 repository 损坏，更像是旧 `WmiPrvSE.exe` provider host 卡住、任务积压或被 WMI quota 限流。

### 恢复验证

仅终止 WMI provider host：

```powershell
Get-Process WmiPrvSE | Stop-Process -Force
```

该动作不会重启 RDP、网络或 `Winmgmt` 服务；WMI 会自动拉起新的 `WmiPrvSE.exe`。

恢复后：

```text
taskkill /F /PID 999999             约 406ms 返回
taskkill /F /IM not_exist_short.exe 约 486ms 返回
taskkill /F /IM chrome.exe          约 195ms 返回
Get-WmiObject Win32_Process         约 439ms 返回
```

连续 10 次：

```text
taskkill /F /IM not_exist_short.exe 106-253ms 返回
```

### 当前判断

- `taskkill` 卡住的直接原因是 WMI COM provider host 异常，而不是 `taskkill.exe` 损坏、RDP 服务停止、普通 CPU/内存不足。
- 当前采集脚本此前高频使用 `Get-CimInstance Win32_Process`，可能增加 WMI 压力；源码 runner 又会在每次初始化浏览器前通过 `taskkill` 做进程清理。两者叠加会放大 Server 2025 的 WMI/provider 长尾。
- Server 2016/2022 不复现，说明这是当前 Server 2025 镜像、补丁、WMI provider 状态、安全组件或系统版本行为差异之一，需要纳入 2025 性能差距解释。

### 复现/诊断脚本

新增：

```text
tools/probe_taskkill_wmi.ps1
```

用法：

```powershell
# 只诊断，不修改系统
powershell.exe -ExecutionPolicy Bypass -File C:\wind\spider\tools\probe_taskkill_wmi.ps1

# 诊断后重启 WmiPrvSE provider host，不重启 Winmgmt/RDP/网络
powershell.exe -ExecutionPolicy Bypass -File C:\wind\spider\tools\probe_taskkill_wmi.ps1 -RestartWmiProvider
```

### 建议

- 生产程序不应无 timeout 调用 `taskkill`。Windows Server 2025 上一旦 WMI provider host 卡住，会直接阻塞 Chrome 初始化。
- 建议替换 Windows 下 `TaskKiller` 实现：使用 Python/WinAPI/psutil 按进程名枚举并 `TerminateProcess`，或至少给 `taskkill` 加 3-5s timeout，超时后记录并继续。
- 性能采集不应高频使用 WMI 进程 I/O；优先使用系统 counters 或低频采样，避免诊断工具本身制造 WMI 压力。
- 若其他 Server 2025 主机复现，应先执行 `probe_taskkill_wmi.ps1`，再考虑重启 `WmiPrvSE` provider host；不要重启 `TermService`，避免断开 RDP。

## 2026-07-30 WMI provider 恢复后原始 C5/N50 复测

在确认 `taskkill/WMI` 已恢复后，使用原始 `wcb_perf_test.exe`、原始 `C:\wcbclient\test\browser-jp.json` 重新执行 C5/N50。为避免再次污染 WMI，新增轻量脚本，仅采集系统 counters，不采 `Win32_Process` 进程 I/O：

```text
tools/run_wcb_system_probe.ps1
C:\wind\spider\perf-runs\system_probe_c5_n50_20260730_153006\
```

测试前 `taskkill/WMI` 健康：

```text
taskkill /F /PID 999999             292ms
taskkill /F /IM not_exist_short.exe 145ms
taskkill /F /IM chrome.exe          141ms
Get-WmiObject Win32_Process         117ms
Get-CimInstance Win32_Process       131ms
```

summary：

```text
run_id=20260730T073012Z_2b337dfb
success=49, fail=1
throughput_per_min=4.4
avg=61.9s, p50=62.8s, p90=80.2s, p95=93.9s, max=115.3s
```

系统 counters：

| 指标 | avg | p95 | max |
|---|---:|---:|---:|
| Available MB | 383.3 | 866 | 1076 |
| Pages/sec | 8349.1 | 36054.0 | 76478.1 |
| Page Reads/sec | 1253.5 | 3962.1 | 21224.6 |
| Disk Read Bytes/sec | 24.12MB/s | 114.98MB/s | 251.37MB/s |
| Disk Write Bytes/sec | 5.49MB/s | 46.03MB/s | 71.09MB/s |
| Avg Disk sec/Read | 0.00 | 0.01 | 0.05 |
| Avg Disk sec/Write | 0.00 | 0.02 | 0.16 |
| Processor Queue Length | 39.8 | 109 | 178 |

日志：

```text
HTTPConnectionPool(host='localhost' ... read timeout=120): 0
ConnectTimeout: 75
Read timed out: 29
facebook.com: 49
twitter.com: 49
web_attachment_detector: 202
检测到0个附件: 49
已kill进程: 199
Out of memory: 0
```

失败任务：

```text
task_id=8
浏览器初始化失败: Chrome failed to start: was killed.
DevToolsActivePort file doesn't exist
ChromeDriver is assuming that Chrome has crashed.
```

测试后 `taskkill/WMI` 仍健康：

```text
taskkill /F /PID 999999             500ms
taskkill /F /IM not_exist_short.exe 156ms
taskkill /F /IM chrome.exe          113ms
Get-WmiObject Win32_Process         211ms
Get-CimInstance Win32_Process       374ms
```

判断：

- 恢复 WMI provider host 后，`HTTPConnectionPool(host='localhost') read timeout=120` 从上一轮原始采集 C5/N50 的 2 次降为 0，说明 `taskkill/WMI` 卡住确实会贡献 webdriver/本地控制链路长尾。
- 但 TPM 仅 4.4/min，仍未回到用户手跑 5.3/min，更未接近 no-autoAttachment 的 7.0-7.6/min；因此 `taskkill/WMI` 不是当前低 TPM 的唯一主因。
- 当前主要耗时又回到 `autoAttachment` 未知链接探测：facebook/twitter 各 49 次、ConnectTimeout 75 次、Read timed out 29 次，且 49 条均未检测到附件。
- 系统硬缺页和磁盘读仍很高：Page Reads/sec avg 1253.5、Disk Read avg 24.12MB/s，说明原始 `autoAttachment` 路径仍会显著放大 Chrome/内存/I/O 压力。
- 1 个 Chrome 初始化失败 `was killed / DevToolsActivePort`，结合高 Pages/sec、低初始可用内存和 C5 启动并发，说明 Server 2025 2GB 环境仍可能在 Chrome 冷启动阶段触发资源边界，而不是单纯 taskkill 卡死。

## 2026-07-30 Defender 进程排除验证

为验证“用户态 `MsMpEng.exe` I/O 不高，但 Defender/WdFilter/进程检查路径仍可能放大 Chrome hard fault 与磁盘读”的假设，新增一组可回滚 Defender 配置。变更前快照：

```text
C:\wind\spider\perf-runs\defender_process_exclusion_20260730_1630\before_mppreference.xml
```

应用项：

```text
ExclusionProcess:
  C:\wcbclient\wcb_perf_test.exe
  C:\wcbclient\GoogleChrome109\wcb_chrome.exe
  C:\wcbclient\GoogleChrome109\wcb_chromedriver.exe
  wcb_perf_test.exe
  wcb_chrome.exe
  wcb_chromedriver.exe
  chrome_common_*.exe

DisableBlockAtFirstSeen=True
MAPSReporting=0
SubmitSamplesConsent=2
```

说明：

- 之前已存在路径排除：`GoogleChrome109`、`chrome_cache`、`Data`、`Log`、临时目录等。
- 本轮增加的是进程排除和云查杀/样本提交关闭。
- 不修改网络、RDP、pagefile。

### C2/N10 原始配置对比

| 场景 | tpm | avg | p50 | p95 | max | ConnectTimeout | localhost 120s |
|---|---:|---:|---:|---:|---:|---:|---:|
| 排除前 | 2.2/min | 44.1s | 39.2s | 69.1s | 72.7s | 17 | 0 |
| Defender 进程排除后 | 1.7/min | 55.1s | 33.8s | 131.4s | 151.7s | 10 | 1 |

系统 counters：

| 指标 | 排除前 avg/p95/max | 排除后 avg/p95/max |
|---|---:|---:|
| Available MB | 584 / 772 / 956 | 534 / 678 / 790 |
| Pages/sec | 1591 / 8775 / 30656 | 224 / 1135 / 8111 |
| Page Reads/sec | 555 / 400 / 25381 | 28 / 179 / 1077 |
| Disk Read Bytes/sec | 3.14 / 22.01 / 41.44 MB/s | 0.69 / 2.27 / 31.62 MB/s |
| Disk Write Bytes/sec | 2.09 / 2.46 / 89.14 MB/s | 0.70 / 1.58 / 55.08 MB/s |
| Processor Queue Length | 5.7 / 25 / 59 | 3.5 / 21 / 50 |

解读：

- Defender 进程排除后，C2/N10 的硬缺页和磁盘读明显下降。
- 吞吐没有提升，主要被 1 次 localhost webdriver timeout 和网络等待波动污染。
- 该结果支持“Defender/WdFilter/进程检查路径会放大 I/O”，但不能单独证明它能提升 TPM。

### C5/N50 原始配置对比

```text
排除后结果：
C:\wind\spider\perf-runs\system_probe_c5_n50_20260730_163945\
```

| 场景 | tpm | success/fail | avg | p50 | p95 | max | localhost 120s |
|---|---:|---:|---:|---:|---:|---:|---:|
| WMI 恢复后、排除前 | 4.4/min | 49/1 | 61.9s | 62.8s | 93.9s | 115.3s | 0 |
| Defender 进程排除后 | 4.1/min | 50/0 | 67.2s | 54.3s | 139.6s | 161.3s | 1 |

系统 counters：

| 指标 | 排除前 avg/p95/max | 排除后 avg/p95/max |
|---|---:|---:|
| Available MB | 383 / 866 / 1076 | 470 / 820 / 1084 |
| Pages/sec | 8349 / 36054 / 76478 | 3014 / 11300 / 40208 |
| Page Reads/sec | 1254 / 3962 / 21225 | 780 / 2481 / 23231 |
| Disk Read Bytes/sec | 24.12 / 114.98 / 251.37 MB/s | 7.64 / 33.39 / 74.42 MB/s |
| Disk Write Bytes/sec | 5.49 / 46.03 / 71.09 MB/s | 1.97 / 5.53 / 59.62 MB/s |
| Processor Queue Length | 39.8 / 109 / 178 | 37.4 / 112 / 162 |

日志：

| 信号 | 排除前 | 排除后 |
|---|---:|---:|
| ConnectTimeout | 75 | 74 |
| Read timed out | 29 | 34 |
| facebook.com | 49 | 50 |
| twitter.com | 49 | 50 |
| `web_attachment_detector` | 202 | 207 |
| Chrome failed to start / DevToolsActivePort | 2 | 0 |

判断：

- Defender 进程排除显著降低了 C5/N50 的 Disk Read 与 Pages/sec，但没有提升 TPM。
- 这说明 Defender/WdFilter/进程检查路径是“2025 下 I/O/hard fault 更高”的重要组成部分，但原始配置的吞吐仍主要受 autoAttachment 外链等待、Chrome 生命周期和偶发 webdriver 长尾控制。
- 如果目标是降低磁盘/硬缺页压力，该系统优化有效；如果目标是提高原始配置 TPM，仅靠 Defender 排除不够。
