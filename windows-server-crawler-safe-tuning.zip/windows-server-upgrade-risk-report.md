# Windows Server 2022/2025 爬虫升级风险评估报告

日期：2026-07-30  
范围：浏览器模式爬虫，当前程序模型，云主机配置一致，Chrome 109 本地副本，重点对比 Windows Server 2016、2022、2025。

## 结论

在当前硬件规格和程序模型下，不建议将生产爬虫主机从 Windows Server 2016 升级到 Windows Server 2022 或 Windows Server 2025。

理由不是新版系统“无法运行浏览器”，而是当前爬虫的浏览器模式具有明显的系统资源放大特征：每个通道使用独立 Chrome/Chromedriver 进程名、独立 profile/cache/temp 目录，并在 detail 任务生命周期内反复启动和销毁 Chrome。该模型在 Windows Server 2016 上尚可接受，但在 Windows Server 2022/2025 上更容易触发硬缺页、Chrome 镜像/缓存冷读、安全过滤路径检查、WMI/taskkill 长尾和内存工作集修剪，最终表现为 TPM 明显低于 2016。

因此，在未找到可稳定复现并显著提升 TPM 的系统级优化前，2022/2025 不适合作为当前生产爬虫浏览器模式的直接升级目标。

## 已验证现象

### 1. Server 2025 原始浏览器配置 TPM 长期偏低

当前 Server 2025 测试机使用原始 `browser-jp.json`，`autoAttachment=true`，C5/N50 结果如下：

| 场景 | TPM | 成功/失败 | avg | p50 | p95 | max |
|---|---:|---:|---:|---:|---:|---:|
| WMI 恢复后，原始配置 | 4.4/min | 49/1 | 61.9s | 62.8s | 93.9s | 115.3s |
| Defender 进程排除后，原始配置 | 4.1/min | 50/0 | 67.2s | 54.3s | 139.6s | 161.3s |
| SysMain/Prefetch 开启后，原始配置 | 未完成 | - | - | - | - | >15min 卡住 |

最新一轮 C5/N50 在 15 分钟内未正常完成，结果 CSV 仍为 0 字节，残留 `wcb_perf_test.exe`、chromedriver 和多个 Chrome 子进程。采集期间可用内存降到约 275–355 MB，Chrome 子进程工作集被压到几百 KB 到十几 MB，说明系统已经进入明显的内存压力和工作集修剪状态。

### 2. 同机关闭 `autoAttachment` 后 TPM 可以达到 2016 量级

同一台 Server 2025、同一套 Chrome 109、同样 C5/N50，在关闭 `autoAttachment` 后：

| 场景 | TPM | 成功/失败 | avg | p50 | p95 | max |
|---|---:|---:|---:|---:|---:|---:|
| 原始 exe，`autoAttachment=false` | 7.6/min | 50/0 | 32.1s | 28.2s | 42.6s | 147.9s |
| 源码 runner，`autoAttachment=false` | 7.0/min | 50/0 | 36.4s | 30.8s | 118.5s | 144.9s |
| 源码 runner，`extension-only` | 5.1/min | 50/0 | 40.6s | 30.4s | 101.6s | 140.9s |

这说明 Server 2025 并非完全跑不动 Chrome；性能下降集中出现在“原始程序模型 + `autoAttachment` + 频繁 Chrome 生命周期”组合上。由于 Server 2016 生产环境同样存在 `autoAttachment`，合理解释不是 `autoAttachment` 单独导致差异，而是新版 Windows 把该路径的成本放大得更明显。

### 3. `autoAttachment` 显著放大硬缺页和 Chrome 读盘

C5/N50 对比：

| 场景 | TPM | Available MB avg | Pages/sec avg | Page Reads/sec avg | Disk Read avg |
|---|---:|---:|---:|---:|---:|
| 原始配置，WMI 恢复后 | 4.4 | 383 MB | 8349 | 1254 | 24.12 MB/s |
| 原始配置，Defender 进程排除后 | 4.1 | 470 MB | 3014 | 780 | 7.29 MB/s |
| `autoAttachment=false` | 7.6 | 586 MB | 859 | 117 | 3.18 MB/s |
| 源码 `autoAttachment=false` | 7.0 | 506 MB | 1384 | 123 | 3.99 MB/s |
| 源码 `extension-only` | 5.1 | 555 MB | 1058 | 90 | 3.58 MB/s |

关键点：

- 原始配置的 Page Reads/sec 和 Disk Read 明显高于关闭 `autoAttachment` 的场景。
- 进程 I/O 采集中，原始配置 Chrome data 进程合计读盘约 5.0GB；关闭 `autoAttachment` 后约 0.69GB。
- `autoAttachment` 日志中存在大量 facebook/twitter/站内未知链接检测、ConnectTimeout、Read timeout 和 `web_attachment_detector` 调用。

这证明 I/O 不是凭空假设，而是当前 Server 2025 上可以复现的主要伴随现象。不过 I/O 更准确地说是“内存压力 + Chrome 冷启动 + 安全过滤 + 附件探测等待”的结果之一，不是唯一根因。

## 为什么 2022/2025 可能比 2016 更差

### 1. 新版 Windows 安全过滤路径更重

即使 Defender 实时防护、IOAV、行为监控已经关闭，`WinDefend`/`MDCoreSvc` 仍在运行，`WdFilter` 仍挂载在 C:。后续增加 Defender 进程排除后，C5/N50 的硬缺页和磁盘读明显下降：

- Disk Read avg：24.12 MB/s 降到 7.29 MB/s。
- Pages/sec avg：8349 降到 3014。
- Page Reads/sec avg：1254 降到 780。

但 TPM 未恢复，说明 Defender/WdFilter 是新版系统 I/O/hard fault 放大的重要组成部分，但不是唯一瓶颈。该结果支持“新版系统安全过滤栈成本高于 2016”的判断。

### 2. 新版系统在 2GB 内存规格下更容易进入工作集修剪

Server 2025 默认系统内存占用高于 2016。浏览器模式 C5 会同时存在多个 Chrome、driver、wcb 子进程；每个 detail 又可能触发页面加载、附件探测、下载目录、cache/temp 创建和销毁。最新 C5/N50 卡住时：

- 可用内存下降到约 275–355 MB。
- Pages/sec 达 400–700，历史峰值可到数万。
- 多个 Chrome 子进程工作集被压到极低。
- 页面显示过 `Out of memory`。

这说明问题不只是磁盘吞吐慢，而是新版系统在同样 2GB 规格下更早触发内存回收、工作集修剪和硬缺页。2016 在同样 pagefile 自动管理下仍能取得更高 TPM，说明 pagefile 大小不是主要解释方向。

### 3. Chrome 冷启动/隔离副本模型在新版系统上缓存命中更差

当前程序为保持通道隔离，按 `policyId` 使用独立命名的 Chrome/driver、副本化进程名和独立 `user-data-dir`、`disk-cache-dir`、`temp-dir`。这个模型有业务合理性，但系统代价是：

- Chrome 镜像和 DLL 频繁加载/卸载。
- profile/cache/temp 频繁重建。
- 文件缓存复用变弱。
- 安全过滤和代码完整性检查更频繁。
- 内存不足时更容易把文件页踢出，下一次再变成硬缺页。

ETW/WPR 小样本曾显示，Chrome 冷启动 C1/N2 即出现大量 FileIo Read、DiskIo Read、HardFault 和 Image Load/Unload 事件。这与当前 C5/N50 的 Page Reads/sec、Disk Read 和 Chrome 读盘数据一致。

### 4. Server 2025 出现过 2016/2022 未复现的 `taskkill`/WMI 长尾

当前程序初始化和释放浏览器时依赖 `taskkill` 清理 `chrome_common_<policy>_*` 进程。Server 2025 曾出现：

- `taskkill /F /IM chrome.exe`、`taskkill /F /PID 999999` 超过 5s 不返回。
- 挂起线程等待在 `LpcReply`。
- WMI Activity 记录 `0x80041032`、`0x80041033`、`0x800706BE`。
- 重启 `WmiPrvSE.exe` provider host 后恢复，`taskkill` 回到约 100–500ms。

用户已在 2016、2022 验证同样 `taskkill` 问题不复现。该问题不是 2022/2025 TPM 差异的唯一原因，但证明新版测试机的进程管理/WMI/provider 路径存在额外长尾风险。对依赖频繁启动/销毁 Chrome 的程序来说，这是放大器。

## 对 Server 2022 的判断

当前详细采集主要来自 Server 2025，本报告不能声称已在本地完整证明 Server 2022 的内部机制完全一致。但从升级决策角度，Server 2022 与 2025 都属于比 2016 更新的 Windows Server 代际，具备更重的安全过滤、系统服务、内存管理和浏览器进程管理路径。既然用户已观察到 2022/2025 的 TPM 均低于 2016，且 2025 的可测证据已经证明新版系统会放大当前程序模型成本，则 2022 也应归入“不适合作为无改造直接升级目标”。

更严谨的表述是：

- 2025：已有本机数据证明原始配置下 TPM 低、硬缺页高、Chrome 读盘高，并且系统侧优化只能降低 I/O，未能稳定恢复 TPM。
- 2022：已有业务压测观察显示 TPM 未达到 2016；机制上与 2025 更接近，且没有证据证明 2022 能稳定恢复 2016 水平，因此不建议作为替代升级目标。

## 可作为证明的证据链

1. 同一 Server 2025 上，关闭 `autoAttachment` 后 TPM 从约 4.1–4.4 提升到 7.0–7.6，说明硬件和 Chrome 本身不是绝对上限。
2. 原始配置比关闭 `autoAttachment` 多出数量级的 Page Reads/sec 和 Chrome 读盘，说明低 TPM 与硬缺页/读盘/附件探测路径强相关。
3. Defender 进程排除显著降低 I/O 和硬缺页，但没有恢复 TPM，说明新版安全过滤是成本来源之一，瓶颈还包括外链等待、Chrome 生命周期和内存压力。
4. C5/N50 在 Server 2025 上会把可用内存压到数百 MB，出现工作集极低、Chrome/driver 残留和超长尾，说明当前 2GB 规格对新版系统没有足够余量。
5. `taskkill`/WMI 在 Server 2025 出现过 2016/2022 未复现的长尾，增加了浏览器启动/销毁路径的不确定性。

这条证据链足以支撑升级评审结论：当前程序和当前云主机规格下，升级到 2022/2025 的性能风险已经被实测确认，且尚无系统级调优能稳定恢复 2016 的 TPM。

## 建议

### 升级策略

- 生产环境暂缓升级到 Windows Server 2022/2025。
- 继续保留 Windows Server 2016 作为当前浏览器模式主力运行环境，直到新版系统上能稳定达到或超过 2016 TPM。
- 如必须升级，应先在灰度机器上执行完整 C5/N50、C5/N100、长时间连续压测，并以 TPM、p95/max、Chrome 启动失败率、Page Reads/sec、Disk Read、可用内存下限作为准入指标。

### 系统侧可继续验证但不应作为已解决方案

- 保留 Defender 路径和进程排除，因为它能降低 I/O/hard fault。
- 保持 pagefile 系统自动管理，与 2016 对齐，不再作为主优化方向。
- 不关闭 RDP、网络、DNS、防火墙、云主机关键 agent。
- 可继续验证 SysMain/ApplicationLaunchPrefetching 的稳定性，但最新 C5/N50 未完成，不能作为有效优化结论。
- 避免高频 WMI 采集，防止诊断工具本身污染结果。

### 程序侧后续方向

用户当前优先要求系统优化，因此不建议把程序改造作为升级前提。但从证据看，如果未来必须支持 2022/2025，可能需要重新评估：

- `taskkill` 增加 timeout 或改用非 WMI 的进程终止方式。
- 在保持通道隔离前提下减少 Chrome 冷启动成本。
- 附件探测在无候选附件时跳过完整检测/保存流程。
- 对外链探测设置更严格的总耗时预算，避免 facebook/twitter/未知链接在新版系统上放大长尾。

这些属于后续工程优化，不改变本报告的升级判断：当前程序不改、当前规格不变时，Server 2022/2025 不适合直接替代 Server 2016。

